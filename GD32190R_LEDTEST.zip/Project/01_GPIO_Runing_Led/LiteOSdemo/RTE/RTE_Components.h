
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Gd32LiteOS' 
 * Target:  'GD32F190R_EVAL' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "gd32f1x0.h"


#endif /* RTE_COMPONENTS_H */
