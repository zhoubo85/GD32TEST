/*!
    \file  readme.txt
    \brief description of the GPIO_Running_Led example
*/

/*
    Copyright (C) 2016 GigaDevice

    2016-01-15, V1.0.0, demo for GD32F1x0(x=7,9)
    2016-05-13, V2.0.0, demo for GD32F1x0(x=7,9)
*/

  This demo is based on the GD32190R-EVAL-V1.2 board, LED1 connected to PA11. LED2 
connected to PA12. LED3 connected to PB6. LED4 connected to PB7.Then, four LEDs 
can light cycles.