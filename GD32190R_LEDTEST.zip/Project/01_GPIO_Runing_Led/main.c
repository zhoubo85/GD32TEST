/*!
    \file  main.c
    \brief GPIO running led
*/

/*
    Copyright (C) 2016 GigaDevice

    2016-01-15, V1.0.0, demo for GD32F1x0(x=7,9)
    2016-05-13, V2.0.0, demo for GD32F1x0(x=7,9)
*/

#include "gd32f1x0.h"
#include "systick.h"
#include "gd32f1x0_eval.h"
#include <stdio.h>

#include "los_sys.h"
#include "los_tick.h"
#include "los_task.ph"
#include "los_config.h"
#include "los_compiler.h"
#include "los_mux.h"

UINT32 g_Testmux01;

#define TSK_PRIOR_HI 4
UINT32 g_uwTskHiID;
UINT32 Example_TaskHi(VOID)
{
  UINT32 uwRet;
  gd_eval_keyinit(KEY_TAMPER, KEY_MODE_EXTI);
	gd_eval_ledinit(LED1);

	while(1)
	{
		uwRet=LOS_MuxPend(g_Testmux01, 5000);
    if(uwRet == LOS_OK)
    {
				gd_eval_ledon(LED1);
				/* insert 200 ms delay */
				LOS_TaskDelay(200);
		 
				/* turn off LEDs */
				gd_eval_ledoff(LED1);
				/* insert 200 ms delay */
				LOS_TaskDelay(200);
				LOS_MuxPost(g_Testmux01);
    }
    else if(uwRet == LOS_ERRNO_MUX_TIMEOUT )
		{
			/* turn on LED1 */
		}
	}
}

UINT32 Example_TaskHi2(VOID)
{
  UINT32 uwRet;
	gd_eval_ledinit(LED2);

	while(1)
	{
		uwRet=LOS_MuxPend(g_Testmux01, 5000);
    if(uwRet == LOS_OK)
    {
				gd_eval_ledon(LED2);
				/* insert 200 ms delay */
				LOS_TaskDelay(3000);
		 
				/* turn off LEDs */
				gd_eval_ledoff(LED2);
				/* insert 200 ms delay */
				LOS_TaskDelay(200);
				LOS_MuxPost(g_Testmux01);
    }
    else if(uwRet == LOS_ERRNO_MUX_TIMEOUT )
		{
			/* turn on LED1 */
		}
	}
}


void EXTI4_15_IRQHandler(void)
{
    if(RESET != exti_interrupt_flag_get(EXTI_13))
		{
			gd_eval_ledtoggle(LED3);
			gd_eval_ledtoggle(LED4);
			//LOS_MuxPost(g_Testmux01);
    }
    exti_interrupt_flag_clear(EXTI_13);
}



UINT32 CreatLedtask(VOID)
{
    UINT32 uwRet;
    TSK_INIT_PARAM_S stInitParam;

		LOS_MuxCreate(&g_Testmux01);
	  gd_eval_ledinit(LED3);
    gd_eval_ledinit(LED4);
	
    LOS_TaskLock();

    stInitParam.pfnTaskEntry = (TSK_ENTRY_FUNC)Example_TaskHi;
    stInitParam.usTaskPrio = TSK_PRIOR_HI;
    stInitParam.pcName = "Led Test";
    stInitParam.uwStackSize = 0x200;
    stInitParam.uwResved   = LOS_TASK_STATUS_DETACHED;

    uwRet = LOS_TaskCreate(&g_uwTskHiID, &stInitParam);
    if (uwRet != LOS_OK)
    {
        LOS_TaskUnlock();
        return LOS_NOK;
    }

    stInitParam.pfnTaskEntry = (TSK_ENTRY_FUNC)Example_TaskHi2;
    stInitParam.usTaskPrio = TSK_PRIOR_HI;
    stInitParam.pcName = "Led Test2";
    stInitParam.uwStackSize = 0x200;
    stInitParam.uwResved   = LOS_TASK_STATUS_DETACHED;

    uwRet = LOS_TaskCreate(&g_uwTskHiID, &stInitParam);
    if (uwRet != LOS_OK)
    {
        LOS_TaskUnlock();
        return LOS_NOK;
    }
		
    LOS_TaskUnlock();

    return LOS_OK;

}
int main(void)
{
    UINT32 uwRet;
    uwRet = osMain();
    if (uwRet != LOS_OK) {
        return LOS_NOK;
    }
		CreatLedtask();
    LOS_Start();
    for (;;);
    /* Replace the dots (...) with your own code.  */
}
#if 0
/*!
    \brief      main function
    \param[in]  none
    \param[out] none
    \retval     none
*/
int main(void)
{  
    gd_eval_ledinit(LED1);
    gd_eval_ledinit(LED2);
    gd_eval_ledinit(LED3);
    gd_eval_ledinit(LED4);
    
    systick_config();
    
    while(1){
        /* turn on LED1 */
        gd_eval_ledon(LED1);
        /* insert 200 ms delay */
        delay_1ms(200);
        
        /* turn on LED2 */
        gd_eval_ledon(LED2);
        /* insert 200 ms delay */
        delay_1ms(200);
        
        /* turn on LED3 */
        gd_eval_ledon(LED3);
        /* insert 200 ms delay */
        delay_1ms(200);
        
        /* turn on LED4 */
        gd_eval_ledon(LED4);
        /* insert 200 ms delay */
        delay_1ms(200);

        /* turn off LEDs */
        gd_eval_ledoff(LED1);
        gd_eval_ledoff(LED2);
        gd_eval_ledoff(LED3);
        gd_eval_ledoff(LED4);
        
        /* insert 200 ms delay */
        delay_1ms(200);
    }
}
#endif
