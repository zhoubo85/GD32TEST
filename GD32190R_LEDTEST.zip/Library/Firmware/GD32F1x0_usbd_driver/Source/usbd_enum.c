/*!
    \file  usbd_enum.c
    \brief USB device enumeration routines
    \note  about USB enumeration, please refer to the USB2.0 protocol
*/

/*
    Copyright (C) 2016 GigaDevice

    2014-09-06, V1.0.0, firmware for GD32F150
    2016-01-15, V1.0.1, firmware for GD32F150
    2016-04-30, V3.0.0, firmware update for GD32F150
*/

#include "usbd_enum.h"
#include "usbd_desc.h"

uint8_t g_address = 0;
uint8_t usbd_string_descriptor[USB_STR_DESC_MAX_SIZE];

/* USB enumeration handle functions */
static void usbd_getdescriptor     (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
static void usbd_setaddress        (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
static void usbd_setconfiguration  (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
static void usbd_getconfiguration  (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
static void usbd_getstatus         (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
static void usbd_setfeature        (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
static void usbd_clearfeature      (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
static void usbd_reserved          (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
static void usbd_setdescriptor     (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
static void usbd_getinterface      (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
static void usbd_setinterface      (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
static void usbd_synchframe        (usbd_core_handle_struct *pudev, usb_device_req_struct *req);

static uint8_t* usbd_string_descriptor_get (uint8_t index, uint16_t *pLen);

/* standard device request handler */
static void (*standard_device_request[])(usbd_core_handle_struct *pudev, usb_device_req_struct *req) =
{
    usbd_getstatus,
    usbd_clearfeature,
    usbd_reserved,
    usbd_setfeature,
    usbd_reserved,
    usbd_setaddress,
    usbd_getdescriptor,
    usbd_setdescriptor,
    usbd_getconfiguration,
    usbd_setconfiguration,
    usbd_getinterface,
    usbd_setinterface,
    usbd_synchframe,
};

/* get string descriptor handler */
static uint8_t* (*standard_string_descriptor_get[])(uint16_t *pLen) = 
{
    usbd_language_id_string_descriptor_get,
    usbd_manufacturer_string_descriptor_get,
    usbd_product_string_descriptor_get,
    usbd_serial_string_descriptor_get
};

/* get standard descriptor handler */
static uint8_t* (*standard_descriptor_get[])(uint8_t index, uint16_t *pLen) = 
{
    usbd_device_descriptor_get,
    usbd_configuration_descriptor_get,
    usbd_string_descriptor_get
};

/*!
    \brief      handle USB standard device request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     USB device operation status
*/
uint8_t  usbd_standard_request (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    /* call device request handle function */
    (*standard_device_request[req->bRequest])(pudev, req);

    return USBD_OK;
}

/*!
    \brief      handle USB device class request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device class request
    \param[out] none
    \retval     USB device operation status
*/
uint8_t  usbd_device_class_request (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    usbd_status_enum ret;

    switch (pudev->dev.status) {
    case USBD_CONFIGURED:
        if (LOWBYTE(req->wIndex) <= USBD_ITF_MAX_NUM) {
            /* call device class handle function */
            ret = (usbd_status_enum)(pudev->dev.class_req_handler(pudev, req));

            if ((0 == req->wLength) && (USBD_OK == ret)) {
                /* no data stage */
                usbd_contrl_status_tx(pudev);
            }
        } else {
            usbd_enum_error(pudev, req);
        }
        break;
    default:
        usbd_enum_error(pudev, req);
        break;
    }

    return USBD_OK;
}

/*!
    \brief      handle USB vendor request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB vendor request
    \param[out] none
    \retval     USB device operation status
*/
uint8_t  usbd_vendor_request (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    /* added by user */

    return USBD_OK;
}

/*!
    \brief      no operation, just for reserved
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_reserved (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    /* no operation */
}

/*!
    \brief      get string descriptor
    \param[in]  index: string descriptor index
    \param[in]  pLen: pointer to string length
    \param[out] none
    \retval     none
*/
static uint8_t* usbd_string_descriptor_get (uint8_t index, uint16_t *pLen)
{
    return standard_string_descriptor_get[index](pLen);
}

/*!
    \brief      handle Get_Status request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_getstatus (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    /* no need */
}

/*!
    \brief      handle USB Clear_Feature request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_clearfeature (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    uint8_t ep_addr = 0;

    switch (req->bmRequestType & USB_REQ_RECIPIENT_MASK) {
    case USB_REQTYPE_DEVICE:
        switch (pudev->dev.status) {
        case USBD_ADDRESSED:
        case USBD_CONFIGURED:
            /* clear device remote wakeup feature */
            if (USB_FEATURE_REMOTE_WAKEUP == req->wValue) {
                pudev->dev.remote_wakeup = 0;
                pudev->dev.class_req_handler(pudev, req);
                usbd_contrl_status_tx(pudev);
            } else if (USB_FEATURE_TEST_MODE == req->wValue) {
                /* can not clear test_mode feature */
                usbd_enum_error(pudev, req);
            }
            break;
        default:
            break;
        }
        break;
    case USB_REQTYPE_INTERFACE:
        switch (pudev->dev.status) {
        case USBD_ADDRESSED:
            usbd_enum_error (pudev, req);
            break;
        case USBD_CONFIGURED:
            if (LOWBYTE(req->wIndex) <= USBD_ITF_MAX_NUM) {
                /* no operation */
            } else {
                usbd_enum_error(pudev, req);
            }
            break;
        default:
            break;
        }
        break;
    case USB_REQTYPE_ENDPOINT:
       ep_addr = LOWBYTE(req->wIndex);
       switch (pudev->dev.status) {
       case USBD_ADDRESSED:
           if (IS_NOT_EP0(ep_addr)) {
               usbd_enum_error(pudev, req);
           }
           break;
       case USBD_CONFIGURED:
           /* clear endpoint halt feature */
           if (USB_FEATURE_ENDP_HALT == req->wValue) {
               if (IS_NOT_EP0(ep_addr)) {
                   usbd_ep_clear_stall(pudev, ep_addr);
               }
           }
           pudev->dev.class_req_handler(pudev, req);
           usbd_contrl_status_tx(pudev);
           break;
       default:
           break;
       }
       break;
    default:
        usbd_enum_error(pudev, req);
        break;
    }
}

/*!
    \brief      handle USB Set_Feature request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_setfeature (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    uint8_t ep_addr = 0;

    switch (req->bmRequestType & USB_REQ_RECIPIENT_MASK) {
    case USB_REQTYPE_DEVICE:
        switch (pudev->dev.status) {
        case USBD_ADDRESSED:
        case USBD_CONFIGURED:
            /* set device remote wakeup feature */
            if (USB_FEATURE_REMOTE_WAKEUP == req->wValue) {
                pudev->dev.remote_wakeup = 1;
                usbd_contrl_status_tx(pudev);
            }
            break;
        default:
            break;
        }
        break;
    case USB_REQTYPE_INTERFACE:
        switch (pudev->dev.status) {
        case USBD_ADDRESSED:
            usbd_enum_error(pudev, req);
            break;
        case USBD_CONFIGURED:
            if (LOWBYTE(req->wIndex) <= USBD_ITF_MAX_NUM) {
                /* no operation */
            } else {
                usbd_enum_error(pudev, req);
            }
            break;
        default:
            break;
        }
        break;
    case USB_REQTYPE_ENDPOINT:
        switch (pudev->dev.status) {
        case USBD_ADDRESSED:
            if (IS_NOT_EP0(ep_addr)) {
                usbd_enum_error(pudev, req);
            }
            break;
        case USBD_CONFIGURED:
            /* set endpoint halt feature */
            if (USB_FEATURE_ENDP_HALT == req->wValue) {
                if (IS_NOT_EP0(ep_addr)) {
                    usbd_ep_stall(pudev, ep_addr);
                }
            }
            usbd_contrl_status_tx(pudev);
            break;
        default:
            break;
        }
        break;
    default:
        usbd_enum_error(pudev, req);
        break;
    }
}

/*!
    \brief      handle USB Set_Address request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_setaddress (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    if ((0 == req->wIndex) && (0 == req->wLength)) {
        g_address = (uint8_t)(req->wValue) & 0x7F;

        if (USBD_CONFIGURED == pudev->dev.status) {
            usbd_enum_error(pudev, req);
        } else {
            usbd_contrl_status_tx(pudev);

            if (0 != g_address) {
                pudev->dev.status  = USBD_ADDRESSED;
            } else {
                pudev->dev.status  = USBD_DEFAULT;
            }
        }
    } else {
        usbd_enum_error(pudev, req);
    }
}

/*!
    \brief      handle USB Get_Descriptor request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_getdescriptor (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    if (USB_REQTYPE_DEVICE == (req->bmRequestType & USB_REQ_RECIPIENT_MASK)) {
        uint8_t desc_index = req->wValue >> 8;
        if (desc_index <= 0x03) {
            uint16_t len = 0;
            uint8_t *pbuf = NULL;

            /* call corresponding descriptor get function */
            pbuf = standard_descriptor_get[desc_index - 1]((uint8_t)(req->wValue) & 0xFF, &len);

            if ((0 != len) && (0 != req->wLength)) {
                len = MIN(len, req->wLength);

                usbd_contrl_tx (pudev, pbuf, len);
            }
        } else {
            usbd_enum_error(pudev, req);
        }
    } else if (USB_REQTYPE_INTERFACE == (req->bmRequestType & USB_REQ_RECIPIENT_MASK)) {
        if (NULL != pudev->dev.class_data_handler) {
            /* get device class special descriptor */
            pudev->dev.class_req_handler(pudev, req);
        }
    }
}

/*!
    \brief      handle USB Set_Descriptor request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_setdescriptor (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    /* no handle */
}

/*!
    \brief      handle USB Get_Configuration request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_getconfiguration (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    /* no handle */
}

/*!
    \brief      handle USB Set_Configuration request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_setconfiguration (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    static uint8_t  cfgidx;

    cfgidx = (uint8_t)(req->wValue);

    if (cfgidx > USBD_CFG_MAX_NUM) {
        usbd_enum_error(pudev, req);
    } else {
        switch (pudev->dev.status) {
        case USBD_ADDRESSED:
            if (cfgidx){
                pudev->dev.config_num = cfgidx;
                pudev->dev.status = USBD_CONFIGURED;
                pudev->dev.class_init(pudev, cfgidx);
                usbd_contrl_status_tx(pudev);
            } else {
                usbd_contrl_status_tx(pudev);
            }
            break;
        case USBD_CONFIGURED:
            if (0 == cfgidx) {
                pudev->dev.status = USBD_ADDRESSED;
                pudev->dev.config_num = cfgidx;
                pudev->dev.class_deinit(pudev, cfgidx);
                usbd_contrl_status_tx(pudev);
            } else if (cfgidx != pudev->dev.config_num) {
                /* clear old configuration */
                pudev->dev.class_deinit(pudev, pudev->dev.config_num);

                /* set new configuration */
                pudev->dev.config_num = cfgidx;
                pudev->dev.class_init(pudev, cfgidx);
                usbd_contrl_status_tx(pudev);
            } else {
                usbd_contrl_status_tx(pudev);
            }
            break;
        default:
            break;
        }
    }
}

/*!
    \brief      handle USB Get_Interface request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_getinterface (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    if (NULL != pudev->dev.class_req_handler) {
        pudev->dev.class_req_handler(pudev, req);
    }
}

/*!
    \brief      handle USB Set_Interface request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_setinterface (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    if (NULL != pudev->dev.class_req_handler) {
        pudev->dev.class_req_handler(pudev, req);
    }
}

/*!
    \brief      handle USB SynchFrame request
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
static void  usbd_synchframe (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    /* no handle */
}


/*!
    \brief      decode setup data packet
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
void  usbd_setup_request_parse (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    req->bmRequestType = *(uint8_t *)(pudev->dev.setup_packet);
    req->bRequest = *(uint8_t *)(pudev->dev.setup_packet + 1);
    req->wValue = SWAPBYTE(pudev->dev.setup_packet + 2);
    req->wIndex = SWAPBYTE(pudev->dev.setup_packet + 4);
    req->wLength = SWAPBYTE(pudev->dev.setup_packet + 6);

    pudev->dev.ctl_count = req->wLength;
    pudev->dev.ctl_state = CTL_SETUP;
}

/*!
    \brief      handle USB enumeration error event
    \param[in]  pudev: pointer to USB device instance
    \param[in]  req: pointer to USB device request
    \param[out] none
    \retval     none
*/
void  usbd_enum_error (usbd_core_handle_struct *pudev, usb_device_req_struct *req)
{
    usbd_ep_stall(pudev, EP0);
}

/*!
    \brief      convert hex 32bits value into unicode char
    \param[in]  value: hex 32bits value
    \param[in]  pbuf: buffer pointer to store unicode char
    \param[in]  len: value length
    \param[out] none
    \retval     none
*/
void int_to_unicode (uint32_t value, uint8_t *pbuf, uint8_t len)
{
    uint8_t index = 0;

    for (index = 0; index < len; index++) {
        if((value >> 28) < 0x0A){
            pbuf[2 * index] = (value >> 28) + '0';
        } else {
            pbuf[2 * index] = (value >> 28) + 'A' - 10; 
        }

        value = value << 4;

        pbuf[2 * index + 1] = 0;
    }
}

/*!
    \brief      convert normal string into unicode one
    \param[in]  desc: descriptor string pointer
    \param[in]  unicode: formatted string (unicode)
    \param[in]  len: descriptor length pointer
    \param[out] len: descriptor length pointer
    \retval     none
*/
void  usbd_unicode_string_get (uint8_t *desc, uint8_t *unicode, uint16_t *len)
{
    uint8_t idx = 1;

    if (desc != NULL) {
        unicode[idx++] =  USB_DESCTYPE_STRING;

        for (; *desc != NULL; ) {
            unicode[idx++] = *desc++;
            unicode[idx++] =  0x00;
        }

        *len = idx;
        unicode[0] = *len;
    }
}
