/*!
    \file  usbd_trans.c
    \brief USB device transactions routines
*/

/*
    Copyright (C) 2016 GigaDevice

    2014-09-06, V1.0.0, firmware for GD32F150
    2016-01-15, V1.0.1, firmware for GD32F150
    2016-04-30, V3.0.0, firmware update for GD32F150
*/

#include "usbd_hw.h"
#include "usbd_trans.h"

extern uint8_t g_address;

/*!
    \brief      USB setup stage processing
    \param[in]  pudev: pointer to USB device instance
    \param[out] none
    \retval     USB device operation status
*/
uint8_t  usbd_setup_transaction (usbd_core_handle_struct *pudev)
{
    usb_device_req_struct req;

    usbd_setup_request_parse (pudev, &req);

    switch (req.bmRequestType & USB_REQ_MASK) {
    /* standard device request */
    case USB_STANDARD_REQ:
        usbd_standard_request(pudev, &req);
        break;
    /* device class request */
    case USB_CLASS_REQ:
        usbd_device_class_request(pudev, &req);
        break;
    /* vendor defined request */
    case USB_VENDOR_REQ:
        usbd_vendor_request(pudev, &req);
        break;
    default:
        usbd_ep_stall(pudev, 0x00);
        break;
    }
    return USBD_OK;
}

/*!
    \brief      data out stage processing
    \param[in]  pudev: pointer to USB device instance
    \param[in]  ep_id: endpoint identifier(0..7)
    \param[out] none
    \retval     USB device operation status
*/
uint8_t  usbd_out_transaction (usbd_core_handle_struct *pudev, uint8_t ep_id)
{
    usb_ep_struct *ep = &pudev->dev.out_ep[ep_id];

    if (0 == ep_id) {
        if (CTL_DATA_OUT == pudev->dev.ctl_state ) {
            if (ep->xfer_len > ep->maxpacket) {
                /* one data packet has been received, update xfer_len */
                ep->xfer_len -= ep->maxpacket;

                /* continue to receive remain data */
                usbd_contrl_continue_rx(pudev, ep->xfer_buf, ep->xfer_len);
            } else {
                if (NULL != (pudev->dev.class_data_handler) &&
                    (USBD_CONFIGURED == pudev->dev.status)) {
                    /* device class handle */
                    pudev->dev.class_data_handler(pudev, USBD_RX, EP0);
                }

                /* enter the control transaction status stage */
                usbd_contrl_status_tx (pudev);
            }
        } else if (CTL_STATUS_OUT == pudev->dev.ctl_state) {
            /* clear endpoint status_out status */
            _Clear_Status_Out(EP0);
        }
    } else {
        if ((NULL != pudev->dev.class_data_handler) &&
            (USBD_CONFIGURED == pudev->dev.status)) {
            pudev->dev.class_data_handler(pudev, USBD_RX, ep_id);
        }
    }
    return USBD_OK;
}

/*!
    \brief      data in stage processing
    \param[in]  pudev: pointer to USB device instance
    \param[in]  ep_id: endpoint identifier(0..7)
    \param[out] none
    \retval     USB device operation status
*/
uint8_t  usbd_in_transaction (usbd_core_handle_struct *pudev, uint8_t ep_id)
{
    usb_ep_struct *ep = &pudev->dev.in_ep[ep_id];

    if (0 == ep_id) {
        if (CTL_DATA_IN == pudev->dev.ctl_state) {
            if (ep->xfer_len > ep->maxpacket) {
                /* one data packet has been transmited, update xfer_len */
                ep->xfer_len -= ep->maxpacket;

                /* continue to receive remain data */
                usbd_contrl_continue_tx(pudev, ep->xfer_buf, ep->xfer_len);
            } else {
#ifndef USB_DFU
                /* transmit length is maxpacket multiple, so send zero length packet */
                if ((0 == (ep->xfer_len % ep->maxpacket)) && (ep->xfer_len < pudev->dev.ctl_count)) {
                    usbd_contrl_continue_tx(pudev, NULL, 0);

                    pudev->dev.ctl_count = 0;
                } else
#endif /* USB_DFU */
                {
                    ep->xfer_len = 0;

                    if ((NULL != pudev->dev.class_data_handler) &&
                        (USBD_CONFIGURED == pudev->dev.status)) {
                        pudev->dev.class_data_handler(pudev, USBD_TX, EP0); 
                    }

                    usbd_contrl_status_rx(pudev);
                }
            }
        } else if ((CTL_STATUS_IN == pudev->dev.ctl_state) && (0 != g_address)) {
            usbd_ep_address_set(pudev, g_address); 
            g_address = 0;
        }
    } else {
        ep->xfer_len -= ep->xfer_count;

        if (0 == ep->xfer_len) {
            if ((NULL != pudev->dev.class_data_handler) &&
                (USBD_CONFIGURED == pudev->dev.status)) {
                pudev->dev.class_data_handler(pudev, USBD_TX, ep_id);
            }
        } else {
            usbd_ep_tx(pudev, ep_id, ep->xfer_buf, ep->xfer_len);
        }
    }

    return USBD_OK;
}
