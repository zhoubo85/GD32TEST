/*!
    \file  usbd_def.h
    \brief general defines for the USB standard
*/

/*
    Copyright (C) 2016 GigaDevice

    2014-09-06, V1.0.0, firmware for GD32F150
    2016-01-15, V1.0.1, firmware for GD32F150
    2016-04-30, V3.0.0, firmware update for GD32F150
*/

#ifndef USBD_DEF_H
#define USBD_DEF_H

#include "usbd_conf.h"

#ifndef NULL
 #define NULL                                           0
#endif

/* constants definitions */
#define  USB_DEV_QUALIFIER_DESC_LEN                     0x0A  /* device qualifier descriptor length */
#define  USB_CFG_DESC_LEN                               0x09  /* configuration descriptor length */

#define  USBD_LANGID_STR_IDX                            0x00  /* language ID string index */
#define  USBD_MFC_STR_IDX                               0x01  /* manufacturer string index */
#define  USBD_PRODUCT_STR_IDX                           0x02  /* product string index */
#define  USBD_SERIAL_STR_IDX                            0x03  /* serial string index */
#define  USBD_CONFIG_STR_IDX                            0x04  /* configuration string index */
#define  USBD_INTERFACE_STR_IDX                         0x05  /* interface string index */

#define  USB_STANDARD_REQ                               0x00  /* standard request */
#define  USB_CLASS_REQ                                  0x20  /* device class request */
#define  USB_VENDOR_REQ                                 0x40  /* vendor request */
#define  USB_REQ_MASK                                   0x60  /* request type mask */

#define  USB_REQTYPE_DEVICE                             0x00  /* request recipient is device */
#define  USB_REQTYPE_INTERFACE                          0x01  /* request recipient is interface */
#define  USB_REQTYPE_ENDPOINT                           0x02  /* request recipient is endpoint */
#define  USB_REQ_RECIPIENT_MASK                         0x1f  /* request recipient mask */

#define  USBREQ_GET_STATUS                              0x00  /* Get_Status standard requeset */
#define  USBREQ_CLEAR_FEATURE                           0x01  /* Clear_Feature standard requeset */
#define  USBREQ_SET_FEATURE                             0x03  /* Set_Feature standard requeset */
#define  USBREQ_SET_ADDRESS                             0x05  /* Set_Address standard requeset */
#define  USBREQ_GET_DESCRIPTOR                          0x06  /* Get_Descriptor standard requeset */
#define  USBREQ_GET_CONFIGURATION                       0x08  /* Get_Configuration standard requeset */
#define  USBREQ_SET_CONFIGURATION                       0x09  /* Set_Configuration standard requeset */
#define  USBREQ_GET_INTERFACE                           0x0A  /* Get_Interface standard requeset */
#define  USBREQ_SET_INTERFACE                           0x0B  /* Set_Interface standard requeset */

#define  USB_DESCTYPE_DEVICE                            0x01  /* device descriptor type */
#define  USB_DESCTYPE_CONFIGURATION                     0x02  /* configuration descriptor type */
#define  USB_DESCTYPE_STRING                            0x03  /* string descriptor type */
#define  USB_DESCTYPE_INTERFACE                         0x04  /* interface descriptor type */
#define  USB_DESCTYPE_ENDPOINT                          0x05  /* endpoint descriptor type */
#define  USB_DESCTYPE_DEVICE_QUALIFIER                  0x06  /* device qualifier descriptor type */
#define  USB_DESCTYPE_OTHER_SPEED_CONFIGURATION         0x07  /* other speed configuration descriptor type */
#define  USB_DESCTYPE_BOS                               0x0F  /* BOS descriptor type */

#define  USB_STATUS_REMOTE_WAKEUP                       2     /* usb is in remote wakeup status */
#define  USB_STATUS_SELF_POWERED                        1     /* usb is in self powered status */

#define  USB_FEATURE_ENDP_HALT                          0     /* usb has endpoint halt feature */
#define  USB_FEATURE_REMOTE_WAKEUP                      1     /* usb has endpoint remote wakeup feature */
#define  USB_FEATURE_TEST_MODE                          2     /* usb has endpoint test mode feature */

/* USB device exported macros */
#define SWAPBYTE(addr)       (((uint16_t)(*((uint8_t *)(addr)))) + \
                             (((uint16_t)(*(((uint8_t *)(addr)) + 1))) << 8))

#define LOWBYTE(x)           ((uint8_t)(x & 0x00FF))
#define HIGHBYTE(x)          ((uint8_t)((x & 0xFF00) >> 8))

#define MIN(a, b)            (((a) < (b)) ? (a) : (b))

#endif /* USBD_DEF_H */
