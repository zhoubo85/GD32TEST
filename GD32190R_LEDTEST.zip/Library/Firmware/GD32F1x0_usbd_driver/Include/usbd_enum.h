/*!
    \file  usbd_enum.h
    \brief USB device enumeration functions prototype
*/

/*
    Copyright (C) 2016 GigaDevice

    2014-09-06, V1.0.0, firmware for GD32F150
    2016-01-15, V1.0.1, firmware for GD32F150
    2016-04-30, V3.0.0, firmware update for GD32F150
*/

#ifndef USBD_ENUM_H
#define USBD_ENUM_H

#include "usbd_core.h"

#define IS_NOT_EP0(ep_addr)  ((ep_addr != 0x00) && (ep_addr != 0x80))

/* function declarations */
/* handle USB standard device request */
uint8_t  usbd_standard_request (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
/* handle device class request */
uint8_t  usbd_device_class_request (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
/* handle USB vendor request */
uint8_t  usbd_vendor_request (usbd_core_handle_struct *pudev, usb_device_req_struct *req);

/* decode setup data packet */
void  usbd_setup_request_parse (usbd_core_handle_struct *pudev, usb_device_req_struct *req);
/* handle USB enumeration error event */
void  usbd_enum_error (usbd_core_handle_struct *pudev, usb_device_req_struct *req);

/* convert hex 32bits value into unicode char */
void  int_to_unicode (uint32_t value, uint8_t *pbuf, uint8_t len);
/* convert normal string into unicode one */
void  usbd_unicode_string_get (uint8_t *desc, uint8_t *unicode, uint16_t *len);

#endif /* USBD_ENUM_H */
