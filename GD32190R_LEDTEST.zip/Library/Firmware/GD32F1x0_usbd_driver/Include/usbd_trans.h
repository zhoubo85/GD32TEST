/*!
    \file  usbd_trans.h
    \brief USB device transactions functions prototype
*/

/*
    Copyright (C) 2016 GigaDevice

    2014-09-06, V1.0.0, firmware for GD32F150
    2016-01-15, V1.0.1, firmware for GD32F150
    2016-04-30, V3.0.0, firmware update for GD32F150
*/

#ifndef USBD_TRANS_H
#define USBD_TRANS_H

#include "usbd_core.h"
#include "usbd_enum.h"

/* function declarations */
/* USB SETUP transaction processing */
uint8_t  usbd_setup_transaction (usbd_core_handle_struct *pudev);
/* USB OUT transaction processing */
uint8_t  usbd_out_transaction (usbd_core_handle_struct *pudev, uint8_t ep_id);
/* USB IN transaction processing */
uint8_t  usbd_in_transaction (usbd_core_handle_struct *pudev, uint8_t ep_id);

#endif /* USBD_TRANS_H */
