/*----------------------------------------------------------------------------
 * Copyright (c) <2013-2015>, <Huawei Technologies Co., Ltd>
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list
 * of conditions and the following disclaimer in the documentation and/or other materials
 * provided with the distribution.
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used
 * to endorse or promote products derived from this software without specific prior written
 * permission.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *---------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------
 * Notice of Export Control Law
 * ===============================================
 * Huawei LiteOS may be subject to applicable export control laws and regulations, which might
 * include those applicable to Huawei LiteOS of U.S. and the country in which you are located.
 * Import, export and usage of Huawei LiteOS in any manner by you shall be in compliance with such
 * applicable export control laws and regulations.
 *---------------------------------------------------------------------------*/
#include "los_demo_entry.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cpluscplus */
#endif /* __cpluscplus */

#include "los_demo_entry.h"
#include "los_task.h"
#include <string.h>


static UINT32 g_uwDemoTaskID;
int dprintf_1(const char *format,...)
{
	return 0;
}
#ifdef LOS_KERNEL_TEST_KEIL_SWSIMU

#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n))) 
#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC))) 
#define TRCENA          0x01000000

struct __FILE 
{
	int handle; /* Add whatever needed */ 
}; 

FILE __stdout;
FILE __stdin; 

int fputc(int ch, FILE *f) 
{ 
	if (DEMCR & TRCENA) 
	{      
		while (ITM_Port32(0) == 0);
		ITM_Port8(0) = ch; 
	}
	return(ch);
}

#endif	
	
	
LITE_OS_SEC_TEXT VOID LOS_Demo_Tskfunc(VOID)
{
#ifdef LOS_KERNEL_TEST_ALL
    /* test all kernel functions */
    Example_TskCaseEntry();
    Example_Dyn_Mem();
    Example_StaticMem();
    Example_Interrupt();
    Example_MsgQueue();
    Example_SndRcvEvent();
    Example_MutexLock();
    Example_Semphore();
    Example_swTimer();
    Example_GetTick();
    Example_list();

#else /* LOS_KERNEL_TEST_ALL */

/* only test some function */
#ifdef LOS_KERNEL_TEST_TASK
    Example_TskCaseEntry();
#endif
#ifdef LOS_KERNEL_TEST_MEM_DYNAMIC
     Example_Dyn_Mem();
#endif
#ifdef LOS_KERNEL_TEST_MEM_STATIC
    Example_StaticMem();
#endif
#ifdef LOS_KERNEL_TEST_INTRRUPT
    Example_Interrupt();
#endif
#ifdef LOS_KERNEL_TEST_QUEUE
    Example_MsgQueue();
#endif
#ifdef LOS_KERNEL_TEST_EVENT
    Example_SndRcvEvent();
#endif 
#ifdef LOS_KERNEL_TEST_MUTEX
    Example_MutexLock();
#endif
#ifdef LOS_KERNEL_TEST_SEMPHORE
    Example_Semphore();
#endif
#ifdef LOS_KERNEL_TEST_SYSTICK
    Example_GetTick();
#endif
#ifdef LOS_KERNEL_TEST_SWTIMER
    Example_swTimer();
#endif
#ifdef LOS_KERNEL_TEST_LIST
    Example_list();
#endif
#endif/* LOS_KERNEL_TEST_ALL */

    while (1)
    {
        LOS_TaskDelay(100);
    }
}

void LOS_Demo_Entry(void)
{
    UINT32 uwRet;
    TSK_INIT_PARAM_S stTaskInitParam;

    (VOID)memset((void *)(&stTaskInitParam), 0, sizeof(TSK_INIT_PARAM_S));
    stTaskInitParam.pfnTaskEntry = (TSK_ENTRY_FUNC)LOS_Demo_Tskfunc;
    stTaskInitParam.uwStackSize = LOSCFG_BASE_CORE_TSK_IDLE_STACK_SIZE;
    stTaskInitParam.pcName = "ApiDemo";
    stTaskInitParam.usTaskPrio = 30;
    uwRet = LOS_TaskCreate(&g_uwDemoTaskID, &stTaskInitParam);

    if (uwRet != LOS_OK)
    {
        dprintf("Api demo test task create failed\n");
        return ;
    }
    return ;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cpluscplus */
#endif /* __cpluscplus */

