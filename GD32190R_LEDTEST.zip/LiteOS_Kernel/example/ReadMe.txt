1: in api, there are kernel api test examples
2: in include , there are kernel api example header file.
3: If you want use kernel api test example , please read the doc/HuaweiLiteOSKernelDevGuide.chm


